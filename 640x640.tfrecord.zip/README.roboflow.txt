
test - v9 Faster R-CNN Inception ResNet V2 640x640
==============================

This dataset was exported via roboflow.ai on March 12, 2021 at 4:55 PM GMT

It includes 513 images.
UI are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Fit within)

No image augmentation techniques were applied.


