
test - v9 Faster R-CNN Inception ResNet V2 640x640
==============================

This dataset was exported via roboflow.ai on March 13, 2021 at 1:25 AM GMT

It includes 513 images.
UI are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Fit within)

No image augmentation techniques were applied.


