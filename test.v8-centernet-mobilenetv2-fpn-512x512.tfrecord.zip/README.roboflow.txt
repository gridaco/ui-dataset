
test - v8 CenterNet MobileNetV2 FPN 512x512
==============================

This dataset was exported via roboflow.ai on March 12, 2021 at 4:36 PM GMT

It includes 513 images.
UI are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Resize to 512x512 (Fit within)

No image augmentation techniques were applied.


