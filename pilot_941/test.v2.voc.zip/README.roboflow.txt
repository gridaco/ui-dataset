
test - v2 2021-02-24 12:47am
==============================

This dataset was exported via roboflow.ai on February 23, 2021 at 3:48 PM GMT

It includes 50 images.
UI are annotated in Pascal VOC format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


